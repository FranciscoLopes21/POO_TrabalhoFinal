#ifndef UTILIZADOR_H
#define UTILIZADOR_H


class Utilizador
{
    int nUtilizador;

    public:
        Utilizador();
        virtual ~Utilizador();

    protected:

    private:
};

#endif // UTILIZADOR_H
