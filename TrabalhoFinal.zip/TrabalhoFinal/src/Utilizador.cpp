#include "Utilizador.h"

Utilizador::Utilizador()
{
    //ctor
}

Utilizador::~Utilizador()
{
    //dtor
}
